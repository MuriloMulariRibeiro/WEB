const { DataTypes, HasMany } = require('sequelize');
const db = require('../database/db');


const Serie = db.sequelize.define('serie',{
    id_serie: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
    },
    nome: {
        type: DataTypes.STRING,
        allonwNull: false,
    },
    categorias: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    avaliação: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    descrição: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    episodeos: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    continuar_assistindo: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
    }
});

Serie.sync({update: true});

module.exports = Serie;