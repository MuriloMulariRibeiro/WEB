const { DataTypes, HasMany } = require('sequelize');
const db = require('../database/db');


const Movie = db.sequelize.define('movie',{
	id_movie: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
    },
    nome: {
        type: DataTypes.STRING,
        allonwNull: false,
    },
    categorias: {
	    type: DataTypes.STRING,
        allowNull: false,
    },
    avaliacao: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    descricao: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    duracao: {
	    type: DataTypes.STRING,
        allowNull: false,
    },
    continuar_assistindo: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
    }
});

Movie.sync({update: true});

module.exports = Movie;