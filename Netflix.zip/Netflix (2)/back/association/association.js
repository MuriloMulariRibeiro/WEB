const Post = require('../model/post');
const User = require('../model/user');
const Serie = require('../model/series')

User.hasMany(Post, {
    foreignKey: 'id_user',
    onDelete: 'CASCADE'
});

 Movie.hasMany(Post, {
    foreignKey: 'id_movie',
    onDelete: 'CASCADE'
});
Series.hasMany(Post, {
    foreignKey: 'id_series',
    onDelete: 'CASCADE'
})

User.hasOne(Post, {

})


Post.belongsTo(User, {
    foreignKey: 'id_user',
})

Post.belongsTo(Movie, {
    foreignKey: 'id_movie',
})
Post.belongsTo(Movie, {
    foreignKey: 'id_serie'
})
