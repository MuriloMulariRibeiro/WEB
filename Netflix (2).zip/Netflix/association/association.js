const Post = require('../model/post');
const User = require('../model/user');

User.hasMany(Post, {
    foreignKey: 'user_id',
    onDelete: 'CASCADE'
});

Movie.hasMany(Post, {
    foreignKey: 'id_movie',
    onDelete: 'CASCADE'
});


Post.belongsTo(User, {
    foreignKey: 'user_id',
})

Post.belongsTo(Movie, {
    foreignKey: 'id_movie',
})