const { DataTypes, HasMany } = require('sequelize');
const db = require('../database/db');
const Post = require('./post');

const Movie = db.sequelize.define('movie',{
	id_movie: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
    },
    categorias: {
	    type: DataTypes.STRING,
        allowNull: false,
    },
    avaliação: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    descrição: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    duração: {
	    type: DataTypes.STRING,
        allowNull: false,
    },
    continuar_assistindo: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
    }
});

Movie.sync({create: true});

module.exports = Movie;