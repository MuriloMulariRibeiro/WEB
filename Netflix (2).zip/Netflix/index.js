const express = require('express');

const User = require('./model/user');
const { where } = require('sequelize');

const Movie = require('./model/movie');

const app = express();

app.use(express.json());

app.post('/create_user', (req, res) => {
    const user = req.body;
    User.create(user).then(() => {
        res.status(200).send("Usuário cadastrado com sucesso");
    }).catch((error) => {
        res.status(403).send("Falha ao cadastrar! " + error);
    });
});

app.post('/create_movie', (req, res) => {
    const movie = req.body;
    Movie.create(Movie).then(() => {
        res.status(200).send("Filme cadastrado com sucesso");
    }).catch((error) => {
        res.status(403).send("Falha ao cadastrar! " + error);
    });
});

app.get('/list_users', (req, res) => {
   
    User.findAll({
        attributes: {
            exclude: ['createdAt', 'updatedAt']
        }
    }).then((users) => {
        res.send(users);
    }).catch((error) => {
        res.send("Falha ao consultar usuários! Erro: " + error);
    });
});

app.get('/list_movie', (req, res) => {
   
    Movie.findAll({
        attributes: {
            exclude: ['createdAt', 'updatedAt']
        }
    }).then((movie) => {
        res.send(movie);
    }).catch((error) => {
        res.send("Falha ao consultar Filmes! Erro: " + error);
    });
});

app.get('/find_user/:id', (req, res) => {
    const id = req.params.id;
    User.findAll({
        where:
        {
            id_user: id,
        },
        attributes:
        {
            exclude: ['createdAt', 'updatedAt']
        }
    }).then((user) => {
        res.send(user);
    }).catch((error) => {
        res.send("Falha ao consultar Usuário! Erro: " + error);
    });
});

app.get('/find_movie/:id', (req, res) => {
    const id = req.params.id;
    Movie.findAll({
        where:
        {
            id_movie: id,
        },
        attributes:
        {
            exclude: ['createdAt', 'updatedAt']
        }
    }).then((movie) => {
        res.send(movie);
    }).catch((error) => {
        res.send("Falha ao consultar Filme! Erro: " + error);
    });
});

app.put('/update_user', (req, res) => {
    const user = req.body;
    User.update(user, {
        where:
        {
            id_user: user.id_user,
        }
    }).then(() => {
        res.send("Usuário atualizado com sucesso!");
    }).catch((error) => {
        res.send("Falha ao atualizar o usuário! Erro: " + error);
    });
});

app.put('/update_movie', (req, res) => {
    const movie = req.body;
    Movie.update(movie, {
        where:
        {
            id_movie: movie.id_movie,
        }
    }).then(() => {
        res.send("Filme atualizado com sucesso!");
    }).catch((error) => {
        res.send("Falha ao atualizar o Filme! Erro: " + error);
    });
});

app.delete('/delete_user/:id', (req, res) => {
    User.destroy({
        where:
        {
            id_user: req.params.id,
        }
    }).then(() => {
        res.send("Usuário deletado com sucesso!");
    }).catch((error) => {
        res.send("Falha ao deletar usuário! Erro: " + error);
    });
});

app.delete('/delete_movie/:id', (req, res) => {
    Movie.destroy({
        where:
        {
            id_movie: req.params.id,
        }
    }).then(() => {
        res.send("Filme deletado com sucesso!");
    }).catch((error) => {
        res.send("Falha ao deletar filme! Erro: " + error);
    });
});



app.listen(3000);