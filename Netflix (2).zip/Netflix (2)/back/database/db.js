const Sequelize = require('sequelize');

const sequelize = new Sequelize(
    'Netflix',
    'root',
    '',
    {
        host: 'localhost',
        dialect: 'mysql'
    }
);

/*sequelize.authenticate().then(function(){
    console.log("Conexão efetuada com sucesso!");
}).catch((error)=>{
    console.log("Falha ao se conectar: " + error);
});
*/

module.exports = {
    Sequelize,
    sequelize
}
