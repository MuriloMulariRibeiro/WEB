const express = require('express');

const User = require('./back/model/user');
const { where } = require('sequelize');

const Movie = require('./back/model/movie');

const Serie = require('./back/model/series')

const app = express();

app.use(express.json());

app.post('/create_user', (req, res) => {
    const user = req.body;
    User.create(user).then(() => {
        res.status(200).send("Usuário cadastrado com sucesso");
    }).catch((error) => {
        res.status(403).send("Falha ao cadastrar! " + error);
    });
});

app.post('/create_movie', (req, res) => {
    const movie = req.body;
    Movie.create(Movie).then(() => {
        res.status(200).send("Filme cadastrado com sucesso");
    }).catch((error) => {
        res.status(403).send("Falha ao cadastrar! " + error);
    });
});

app.post('/create_serie', (req, res) => {
    const serie = req.body;
    Serie.create(Serie).then(() => {
        res.status(200).send("Serie cadastrado com sucesso");
    }).catch((error) => {
        res.status(403).send("Falha ao cadastrar! " + error);
    });
});

app.get('/list_users', (req, res) => {
   
    User.findAll({
        attributes: {
            exclude: ['createdAt', 'updatedAt']
        }
    }).then((users) => {
        res.send(users);
    }).catch((error) => {
        res.send("Falha ao consultar usuários! Erro: " + error);
    });
});

app.get('/list_movie', (req, res) => {
   
    Movie.findAll({
        attributes: {
            exclude: ['createdAt', 'updatedAt']
        }
    }).then((movie) => {
        res.send(movie);
    }).catch((error) => {
        res.send("Falha ao consultar Filmes! Erro: " + error);
    });
});

app.get('/list_serie', (req, res) => {
   
    Serie.findAll({
        attributes: {
            exclude: ['createdAt', 'updatedAt']
        }
    }).then((movie) => {
        res.send(movie);
    }).catch((error) => {
        res.send("Falha ao consultar Series! Erro: " + error);
    });
});

app.get('/find_user/:id', (req, res) => {
    const id = req.params.id;
    User.findAll({
        where:
        {
            id_user: id,
        },
        attributes:
        {
            exclude: ['createdAt', 'updatedAt']
        }
    }).then((user) => {
        res.send(user);
    }).catch((error) => {
        res.send("Falha ao consultar Usuário! Erro: " + error);
    });
});

app.get('/find_movie/:id', (req, res) => {
    const id = req.params.id;
    Movie.findAll({
        where:
        {
            id_movie: id,
        },
        attributes:
        {
            exclude: ['createdAt', 'updatedAt']
        }
    }).then((movie) => {
        res.send(movie);
    }).catch((error) => {
        res.send("Falha ao consultar Filme! Erro: " + error);
    });
});

app.get('/find_serie/:id', (req, res) => {
    const id = req.params.id;
    Serie.findAll({
        where:
        {
            id_serie: id,
        },
        attributes:
        {
            exclude: ['createdAt', 'updatedAt']
        }
    }).then((serie) => {
        res.send(serie);
    }).catch((error) => {
        res.send("Falha ao consultar serie! Erro: " + error);
    });
});


app.put('/update_user/:id', (req, res) => {
    const user = req.body;
    User.update(user, {
        where:
        {
            id_user: user.id_user,
        }
    }).then(() => {
        res.send("Usuário atualizado com sucesso!");
    }).catch((error) => {
        res.send("Falha ao atualizar o usuário! Erro: " + error);
    });
});

app.put('/update_movie/:id', (req, res) => {
    const movie = req.body;
    Movie.update(movie, {
        where:
        {
            id_movie: movie.id_movie,
        }
    }).then(() => {
        res.send("Filme atualizado com sucesso!");
    }).catch((error) => {
        res.send("Falha ao atualizar o Filme! Erro: " + error);
    });
});

app.put('/update_serie/:id', (req, res) => {
    const serie = req.body;
    Serie.update(serie, {
        where:
        {
            id_serie: serie.id_serie,
        }
    }).then(() => {
        res.send("Serie atualizado com sucesso!");
    }).catch((error) => {
        res.send("Falha ao atualizar o Serie! Erro: " + error);
    });
});


app.delete('/delete_user/:id', (req, res) => {
    User.destroy({
        where:
        {
            id_user: req.params.id,
        }
    }).then(() => {
        res.send("Usuário deletado com sucesso!");
    }).catch((error) => {
        res.send("Falha ao deletar usuário! Erro: " + error);
    });
});

app.delete('/delete_movie/:id', (req, res) => {
    Movie.destroy({
        where:
        {
            id_movie: req.params.id,
        }
    }).then(() => {
        res.send("Filme deletado com sucesso!");
    }).catch((error) => {
        res.send("Falha ao deletar filme! Erro: " + error);
    });
});

app.delete('/delete_serie/:id', (req, res) => {
    Serie.destroy({
        where:
        {
            id_serie: req.params.id,
        }
    }).then(() => {
        res.send("Serie deletado com sucesso!");
    }).catch((error) => {
        res.send("Falha ao deletar Serie! Erro: " + error);
    });
});



app.listen(3001);